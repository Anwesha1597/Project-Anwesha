-- create a table
CREATE table STUDENTInfo (
    STU_ID int,
    STU_NAME varchar(20),
    DOB Date,
    PHONE_NO int,
    EMAIL_ID varchar(20),
    ADDRESS varchar(20)

);

 CREATE table CoursesInfo (
   COURSE_ID int,
   COURSE_NAME varchar(20),
   COURSE_INSTRUCTOR_NAME varchar(20)
);

CREATE table EnrollmentInfo (
  EnrollmentID INT,
  StudentID INT, -- Foreign key to link a student to an enrollment
  CourseID INT,  -- Foreign key to link a course to an enrollment
  ENROLL_STATUS varchar(20),
  FOREIGN KEY (StudentID) REFERENCES STUDENTInfo(StudentID),
  FOREIGN KEY (CourseID) REFERENCES CoursesInfo(CourseID)
);

-- insert some values
INSERT into "StudentInfo" values (1,'Ram','1997-05-08',241433,'ram@gmail.com','Ashoknagar'),(2,'Ravi','1999-05-09',248439,'ravi@gmail.com','Vidyanagar'),
(3,'Neha','1992-01-08',212468,'neha@gmail.com','Anantnagar'),(4,'Anu','1997-06-02',274365,'anu@gmail.com','Indiranagar'),(5,'Reena','1990-07-03',289608,'reena@gmail.com','Vikramnagar');

SELECT * from "StudentInfo";

INSERT into "CoursesInfo" values (1, 'Datascience', 'Naveen'), (2, 'Embeddedsystem', 'Manoj'),(3, 'VLSISystem', 'Abhinash'),(4, 'JAVA', 'Sashi'),
 (5, 'AWS', 'Krishna');

SELECT * from "CoursesInfo";

INSERT into "EnrollmentInfo" values (1, 1, 1, 'Enrolled'), (2, 1, 2, 'Not Enrolled'), (3, 1, 3, 'Enrolled'), (4, 4, 4, 'Not Enrolled'), (5, 5, 5, 'Enrolled');

SELECT * from "EnrollmentInfo";

-- Query to display Name, Contact and Enrollment status

Select "StudentInfo"."STU_NAME", "StudentInfo"."PHONE_NO", "EnrollmentInfo"."ENROLL_STATUS"

from  "StudentInfo"

Left JOIN "EnrollmentInfo" on "StudentInfo"."STU_ID" = "EnrollmentInfo"."COURSE_ID";

-- Query to retrieve list of students enrolled

Select "StudentInfo"."STU_NAME", "CoursesInfo"."COURSE_NAME"

from  "StudentInfo"

Left JOIN "CoursesInfo" on "StudentInfo"."STU_ID" = "CoursesInfo"."COURSE_ID";

-- Query to retrieve Course Information

SELECT "COURSE_NAME", "COURSE_INSTRUCTOR_NAME" FROM "CoursesInfo";

-- Query to retrieve course information for a specific course

Select * from "CoursesInfo" where "COURSE_NAME" = 'Datascience';

-- Query to retrieve course information for multiple courses

Select * FROM "CoursesInfo";

-- Query to retrieve the number of students enrolled in each course

SELECT "COURSE_NAME", COUNT(*) AS NumberOfStudentsEnrolled
FROM "CoursesInfo"
GROUP BY "COURSE_NAME";

-- Query to retrieve the list of students enrolled in a specific course

Select "StudentInfo"."STU_NAME"
from "StudentInfo"
Inner Join "EnrollmentInfo" on "StudentInfo"."STU_ID" = "EnrollmentInfo"."COURSE_ID"
Inner Join "CoursesInfo" on "EnrollmentInfo"."EnrollmentID"="CoursesInfo"."COURSE_ID"
Where "CoursesInfo"."COURSE_NAME" = 'Embeddedsystem';

-- Query to retrieve count of enrolled students for each instructor

SELECT "COURSE_INSTRUCTOR_NAME", COUNT(*) AS NumberOfStudentsEnrolled
FROM "CoursesInfo"
GROUP BY "COURSE_INSTRUCTOR_NAME";

-- Query to retrieve the list of students enrolled in multiple courses

SELECT "StudentInfo"."STU_NAME", COUNT("EnrollmentInfo"."COURSE_ID") AS num_of_courses_enrolled
FROM "StudentInfo"
JOIN "EnrollmentInfo" ON "StudentInfo"."STU_ID" = "EnrollmentInfo"."StudentID"
GROUP BY "StudentInfo"."STU_ID"
HAVING COUNT("EnrollmentInfo"."COURSE_ID") > '2';

-- Query to retrieve the courses that have highest number of enrolled students (highest to lowest) 

SELECT "CoursesInfo"."COURSE_ID", "CoursesInfo"."COURSE_NAME", COUNT("EnrollmentInfo"."StudentID") AS NumberOfStudentsEnrolled
FROM "CoursesInfo"
LEFT JOIN "EnrollmentInfo" ON "CoursesInfo"."COURSE_ID" = "EnrollmentInfo"."COURSE_ID"
GROUP BY "CoursesInfo"."COURSE_ID", "CoursesInfo"."COURSE_NAME"
ORDER BY NumberOfStudentsEnrolled DESC;