Select * from student_info;

Insert into student_table values (1,'Ram', 'ECE', 'ram@gmail.com', 8597654321, 'RAIPUR', '1997-06-02', 'MALE', 'Electronics', 7, 'B');
Insert into student_table values (2,'Naveen', 'CSE', 'naveen@gmail.com', 9983443210, 'YZG', '1996-01-05', 'MALE', 'IT', 8, 'A');
Insert into student_table values (3,'Neelima','MECH', 'neelima@gmail.com', 9987546543, 'SURAT', '1992-01-08', 'FEMALE', 'Thermodynamics', 6, 'C');
Insert into student_table values (4,'Monika', 'CIVIL', 'monika@gmail.com', 8597459825, 'GAJPATI', '1997-01-04', 'FEMALE', 'ED drawing', 5, 'D');
Insert into student_table values (5,'Mohan', 'AG', 'mohan@gmail.com', 7674535432, 'SRIKAKULAM', '1994-08-03', 'MALE', 'Soil conservation', 4, 'E');
Insert into student_table values (6,'Vijay', 'EEE', 'vijay@gmail.com', 8889654321, 'VIJAYNAGARAM', '1993-02-02', 'MALE', 'Electrical', 7, 'B');
Insert into student_table values (7,'Anu', 'AE&I', 'anu@gmail.com', 9947654871, 'JEYPORE', '1997-06-08', 'FEMALE', 'Analog electronics', 4, 'E');
Insert into student_table values (8,'Shruti', 'IT', 'shruti@gmail.com', 9987654321, 'GUJARAT', '1991-07-09', 'FEMALE', 'Java', 7, 'B');
Insert into student_table values (9,'Manoj', 'ECE', 'manoj@gmail.com', 7777654321, 'JHARKHAND', '1990-05-05', 'MALE', 'Electronics', 6, 'C');
Insert into student_table values (10,'Shiva', 'CSE', 'shiva@gmail.com', 8954543217, 'BIHAR', '1996-04-02', 'MALE', 'IT', 9, 'E');

-- Query to retrieve all student information from student_table & sort them in DESC order by grade

Select * from student_table order by Grade DESC;

-- Query to retrieve all the male student information

Select * from student_table where gender = 'MALE';

-- Query for students with GPA less than 5.0

Select * from student_table where gpa < 5;

-- Query to write an update statement to modify the email & grade of a student with a specific ID

UPDATE student_table SET email_id = 'monika@harman.com', Grade = 'A' WHERE student_id = 4;

-- Query to retrieve the names and ages of students who has Grade 'B'

SELECT stu_name, DATE_PART('year', AGE(date_of_birth)) AS Age FROM student_table WHERE grade = 'B';

-- Create a query to group the student table by the department and gender column and calculate the average GPA for each combination

SELECT department, gender, AVG(gpa) AS AverageGPA FROM student_table GROUP BY department, gender;

-- Rename the student_table to student_info using the appropriate SQL statement

ALTER TABLE student_table RENAME TO student_info;

-- Query to retrieve the name of the student with highest gpa
 
 SELECT stu_name FROM student_info ORDER BY gpa DESC LIMIT 1;
 



