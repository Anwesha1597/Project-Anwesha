Select * from "Sales_Sample";

Insert into "Sales_Sample" values (1,'East','2020-09-06',500),(2,'West','2021-06-02',1000),(3,'North','2023-08-01',2000),
(4,'South','2022-01-05',3000),(5,'West','2021-07-04',4000),(6,'North','2023-05-02',5000),(7,'East','2019-04-03',6000),
(8,'West','2018-06-15',7000),(9,'South','2017-02-06',8000),(10,'North','2016-05-06',9000);

-- Query to Perform drill-down from region to product level to understand Sales Performance

SELECT "Region", "Product_ID", SUM("Sales_Amount") AS Total_Sales
FROM "Sales_Sample" GROUP BY "Region", "Product_ID"
ORDER BY "Region", Total_Sales DESC;

--  Query to Perform ROLL UP from product to region level to view total_sales by Region

SELECT "Product_ID","Region", SUM("Sales_Amount") AS Total_Sales
FROM "Sales_Sample" GROUP BY ROLLUP ("Product_ID","Region") ORDER BY "Product_ID","Region";

-- Query to Perform sales_data from different perspectives, such as Product, Region and Date

SELECT "Product_ID", "Region", "Date", SUM("Sales_Amount") AS Total_Sales FROM "Sales_Sample" GROUP BY "Product_ID", "Region", "Date"
ORDER BY "Product_ID", "Region", "Date";

-- Query to Slice the data to view sales for a particular region or date range

SELECT "Region", SUM("Sales_Amount") AS Total_Sales
FROM "Sales_Sample" GROUP BY "Region" ORDER BY "Region";

-- Query to Dice to view the sales for specific combinations of Product, Region and Date

SELECT "Product_ID", "Region", "Date" FROM "Sales_Sample" 
GROUP BY "Product_ID", "Region", "Date"
ORDER BY "Product_ID", "Region", "Date";
