SELECT * FROM "Events_table"

INSERT INTO "Events_table" values (1, 'Stakeholdermanagement', '2023-05-06', 'Bangalore', 'Managing Stakeholder Communication'),
(2, 'Productmanagement', '2022-04-03', 'Hyderabad', 'Product management Skills'), (3, 'Newhiresonboarding', '2023-08-01', 'Bhubaneswar', 'Onboarding Assesments'),
(4, 'RBStrainings for SQL', '2021-09-06', 'Mumbai', 'Advance SQL for Intermediate learners'), (5,'ICLeaftrainings', '2023-10-05', 'Pune', 'Advance knowledge on PostgresSQL');

SELECT * FROM "Attendees_table"

INSERT INTO "Attendees_table" values (1, 'Anwesha', 9876549834, 'anwesha@gmail.com', 'Bangalore'),(2, 'Manisha', 9658432763, 'manisha@gmail.com', 'Chennai'),
(3, 'Sanjana', 7765489304, 'sanajana@gmail.com', 'Delhi'), (4, 'Mittal', 9856470345, 'mittal@gmail.com', 'Pune'), (5, 'Rohit', 9987654032, 'rohit@gmail.com', 'Mumbai');

SELECT * FROM "Registrations_table"

INSERT INTO "Registrations_table" values (1, 1, 1, '2023-05-07', 20000), (2, 2, 2, '2020-04-09', 15000),(3, 3, 3, '2021-04-03', 10000),
(4, 4, 4, '2019-02-01', 5000),(5, 5, 5, '2018-06-4', 2000);

-- Query for inserting a new event, updating an events information, Deleting an event

--Inserting a new event

INSERT INTO "Events_table" values (7, 'New-Sample', '2023-08-09', 'Bangalore', 'Managing Stakeholder Communication');

-- Updating an Events information

UPDATE "Events_table" SET "Event_Name" = 'Advance Excel', "Event_Date" = '2023-03-01', "Event_Location" = 'BBSR', "Event_Description" = 'Advance Excel Skills' 
WHERE "Event_ID" = '3';

-- Deleting an event

DELETE FROM "Events_table" WHERE "Event_ID" = '7';

-- Manage Track Attendees & Handle Events

-- Inserting a new Attendee

INSERT INTO "Attendees_table" values (7, 'Arpita', 9987543690, 'arpita@gmail.com', 'Coimbatore');

-- Registering an Attendee for an event

INSERT INTO "Registrations_table" values (7, 6, 6, '2021-04-08', 30000);

-- Develop queries to retrieve Event information, generate Attendees lists and calculate event attendee statistics

SELECT * FROM "Events_table";

SELECT "Attendee_Name" from "Attendees_table";

SELECT E."Event_ID", E."Event_Name", COUNT(R."Attendee_ID") AS total_attendees
FROM "Events_table" E LEFT JOIN "Registrations_table" R ON E."Event_ID" = R."Event_ID"
GROUP BY E."Event_ID", E."Event_Name";

